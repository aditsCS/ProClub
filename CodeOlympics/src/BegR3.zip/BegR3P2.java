
public class BegR3P2 {
	
	public String replaceWords() {
		String str = "The fat cat met another fat cat at the park.";
		
		// replace "fat" with "chubby"
		// str = str.replace("", "");
		
		// replace "cat" with "kitten"
		// str = str.replace("", "");
		
		return str;
	}

}