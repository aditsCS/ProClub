
public class BegR3P1 {

	public int calculateArea(int width, int height) {
		int area = 0;
		return area;
	}
	
}
