
public class BegR3P3 {

	public String areaCode(String phone) {
			
		return "Area Code: ";
	}
	
}
