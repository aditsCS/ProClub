
public class BegR3P4 {

	public void printUniqueFactors(int a) {
		for(int i= 1; i <= a; i++){

			//code here
		
		}
		
	}
}
