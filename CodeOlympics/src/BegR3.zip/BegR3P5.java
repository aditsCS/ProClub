
public class BegR3P5 {
	
	public void getFactors(int a) {
		for(int w = 1; w <= a; w++ ){
		    if(a % w == 0){
		        System.out.println(w);
		    } 
		}
		
	}

}
