
public class BegR1P4 {
	public String copyString(String str, int repeatNumber){
		//Enter code here
		
		
		
		
		
		//Returns the string, str, repeated repeatNumber amount of times
		return "";
	}
}
