
public class BegR1P5 {
	public void printPyramid(String str, int num){
		//Enter code here
		
		
		
		
		
		
		//Print a pyramid of str.
	}
	
	public void printStringN(String str, int num){ //prints a string, str, num times
		for(int i = 1; i <= num; i++){
			System.out.print(str + " ");
		}
	}
}
