
public class BegR1P3 {
	public int speedTicket(int speed){
		//Enter your code here
		
		
		
		
		//returns 0 = no ticket (<60 speed). 1 = small ticket (btwn 60 and 80). 2 = (large ticket 80+)
		return 0;
	}
}
