
public class BegR1P2 {
	public boolean isLastDigit(int num1, int num2){
		//Enter your code here
		
		
		
		
		
		
		//Return true if num1 and num2 have the same last digit, false if otherwise.
		return false;
	}
}
