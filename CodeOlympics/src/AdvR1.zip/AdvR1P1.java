
public class AdvR1P1 {

	public String replaceAll(String str, String delete) {
		return "";
	}
	
}
