
public class AdvR1P5 {
	
	public String allSubstrings(String str) {
		return "";
	}

}
