
public class AdvR1P4 {

	public String overlap(String str, String str2) {
		return "";
	}
	
}
