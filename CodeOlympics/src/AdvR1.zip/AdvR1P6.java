
public class AdvR1P6 {

	public String stretch(String str, int scale) {
		return "";
	}
	
}
