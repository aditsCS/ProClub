
public class AdvR1P2 {
	
	public String anagram(String str) {
		return "";
	}

}
