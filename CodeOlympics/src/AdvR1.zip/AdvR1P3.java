
public class AdvR1P3 {
	
	public boolean isAnagram(String str, String str2) {
		return false;
	}

}
