
public class AdvR2P4 {
	
	public int sequenceConstant(int[] sequence) {
		return 0;
	}

}
