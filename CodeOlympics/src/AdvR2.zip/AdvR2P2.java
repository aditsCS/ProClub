
public class AdvR2P2 {

	public int sumDigits(int n) {
		return 0;
	}
	
}
