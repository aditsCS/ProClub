
public class AdvR2P1 {

	public int findMissing(int[] arr) {
		return 0;
	}
	
}
