
public class AdvR2P5 {

	public String factor(int n) {
		return "";
	}
	
}
