
public class AdvR3P1 {
	
	public String toCoins(String dollarValue) {
		return "";
	}

}
