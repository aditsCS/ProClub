
public class AdvR3P3 {
	
	public int[] modifiedArray(int[] arr, int i, int val) {
		return new int[5];
	}

}
