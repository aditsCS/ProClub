
public class AdvR3P4 {

	public int middle(int[] arr) {
		return 0;
	}
	
}
