
public class AdvR3P5 {

	public int toDecimal(int binary) {
		return 0;
	}
	
}
