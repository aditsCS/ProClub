
public class AdvR3P2 {

	public int toNumber(String numberWord) {
		return 0;
	}
	
}
