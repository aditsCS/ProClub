
public class BegR2P3 {
	public int sumOfNumbers(int n){
		//Enter code here
		
		
		
		
		
		
		//Returns the sum of the first n numbers
		return 0;
	}
}
