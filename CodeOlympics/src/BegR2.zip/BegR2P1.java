
public class BegR2P1 {
	public void printA(String name1, String name2, String name3){
		//Enter code here
		
		
		
		
		
		
		//System.out.println(names that start with A)
	}
	
	public boolean startsWithA(String str){ //true if a string starts with A, false if not
		if(str.charAt(0) == 'a' || str.charAt(0) == 'A')
			return true;
		else
			return false;
	}
}
