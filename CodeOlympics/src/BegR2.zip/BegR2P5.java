
public class BegR2P5 {
	public void printStickFigure(){
		//Enter code here
		
		
		
		
		
		//Print stick figure! Extra points for creativity!!
	}
}
