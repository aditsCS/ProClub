
public class BegR2P4 {
	public boolean isMultipleOf(int num){
		//Enter code here
		
		
		
		//Return true if number is multiple of 10 or 4, false if otherwise
		return false;
	}
}
