
public class BegR2P2 {
	public void printColorsOfRainbow(){
		//Enter code here
		print("Colors of the rainbow:");
		
		
		
		
		//Print colors of the rainbow
	}
	
	public void print(String str){
		System.out.println(str);
	}
}
